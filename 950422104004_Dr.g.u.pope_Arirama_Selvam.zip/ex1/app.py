from flask import Flask, render_template, request, jsonify

app = Flask(__name__)

# Predefined responses for simplicity
responses = {
    "hi": "Hello! How can I help you today?",
    "hello": "Hi! What can I do for you?",
    "help": "I'm here to assist you! What do you need help with?",
    "bye": "Goodbye! Have a great day!",
     "hi": "Hello! How can I help you today?",
    "hello": "Hi! What can I do for you?",
    "help": "I'm here to assist you! What do you need help with?",
    "bye": "Goodbye! Have a great day!",
    "how are you": "I'm doing great, thank you! How about you?",
    "good morning": "Good morning! Hope you have a wonderful day!",
    "good afternoon": "Good afternoon! How’s your day going?",
    "good evening": "Good evening! How can I assist you tonight?",
    "how’s it going": "It’s going well, thanks for asking! How about you?",
    "what's up": "Not much, just here to help! What’s up with you?",
    "thanks": "You're welcome! Let me know if you need anything else.",
    "thank you": "Anytime! Happy to help.",
    "thank you so much": "You're very welcome! I’m glad I could assist.",
    "no problem": "It’s no trouble at all! Happy to help.",
    "sorry": "No worries at all! How can I assist you?",
    "excuse me": "Yes? How can I help you?",
    "please": "Of course! How can I assist you?",
    "sorry to bother you": "Not a bother at all! What can I do for you?",
    "yes": "Great! What would you like help with?",
    "no": "Got it. Let me know if you change your mind.",
    "maybe": "Okay, just let me know when you're ready!",
    "who are you": "I'm ChatGPT, your assistant. How can I help today?",
    "what is your name": "I’m ChatGPT. How can I assist you today?",
    "can you help me": "Of course! What do you need help with?",
    "could you help me": "Absolutely! Just let me know what you need.",
    "can you do that": "Sure thing! I’ll handle it.",
    "what is this": "This is an AI-powered assistant. How can I assist you?",
    "where are you from": "I exist in the cloud, so I’m everywhere and nowhere!",
    "what can you do": "I can help answer questions, provide information, and assist with various tasks. Just ask!",
    "tell me a joke": "Why don’t skeletons fight each other? They don’t have the guts!",
    "tell me a fun fact": "Did you know honey never spoils? Archaeologists have found pots of honey in ancient tombs that are still edible!",
    "goodbye": "Goodbye! Take care and feel free to come back anytime!",
    "see you later": "See you! Have a wonderful day!",
    "talk to you soon": "Looking forward to it! Take care!",
    "goodnight": "Goodnight! Sleep well and talk to you soon!",
    "have a nice day": "Thank you! Wishing you the same!",
    "have a great day": "Thanks! Hope your day is amazing too!",
    "take care": "You too! Stay safe!",
    "good to see you": "It’s great to see you too! How can I help?",
    "nice to meet you": "Nice to meet you too! What can I assist with today?",
    "long time no see": "It’s been a while! How have you been?",
    "what’s your favorite color": "I don’t have a favorite, but I think blue is nice!",
    "how old are you": "I don’t age, but I’m always here to help you!",
    "where do you live": "I exist in the cloud—here to assist from anywhere!",
    "why are you here": "I’m here to help answer your questions and assist with whatever you need.",
    "what do you do": "I help with information, provide advice, and assist in a variety of tasks.",
    "can I ask you something": "Of course! What’s on your mind?",
    "are you a robot": "I’m an AI, not a robot, but I’m here to assist you just the same!",
    "what is AI": "AI stands for Artificial Intelligence. It’s technology that allows machines to think and learn like humans.",
    "do you know everything": "I know a lot, but I don’t have all the answers. I’m always learning, though!",
    "are you real": "I’m real in the sense that I exist to assist you, but I’m not a person.",
    "how can I help you": "Thank you for asking! How can I help you today?",
    "what should I do": "Could you clarify what you're asking about? I’d love to help you figure it out.",
    "where is [place]": "I can help with that! Could you tell me more about what you’re looking for?",
    "tell me more about [topic]": "Sure! Here’s more about that topic: [add information]. Let me know if you need further details!",
    "what time is it": "I don't have access to real-time data, but you can easily check the time on your device.",
    "what's the weather like": "I can’t provide live weather updates, but you can check a weather website or app for that info.",
    "can you search the web": "I can't browse the web in real-time, but I have lots of knowledge up to 2023!",
    "do you like [something]": "I don't have preferences, but I can share information or help with anything you like!",
    "where is the nearest [place]": "I can't check location services, but I suggest using a map or GPS for the most accurate results.",
    "is that so": "Yes, that's correct! Let me know if you need more info.",
    "are you sure": "Yes, I'm confident! If you’d like more details, feel free to ask.",
    "that’s interesting": "I’m glad you think so! Let me know if you want to learn more.",
    "really": "Yep, really! What else can I help with?",
    "I don’t know": "That’s okay! Let me know if you’d like to explore it together.",
    "I think so": "Great! Let me know if you need more details or help with something else.",
    "that’s great": "I’m glad you think so! How can I assist you further?",
    "no way": "Haha, I promise it’s true! Want to know more?",
    "I’m bored": "Let’s fix that! I can tell you a joke, share a fun fact, or help with anything else!",
    "I’m tired": "I hear you! Take it easy and rest up. I’m here whenever you need help.",
    "I’m hungry": "I hope you get something delicious soon! Need help finding recipes?",
    "I’m happy": "That’s awesome! What’s making you happy today?",
    "I’m sad": "I’m sorry to hear that. Want to talk about it or need a distraction?",
    "I’m excited": "That’s great to hear! What are you excited about?",
    "can you remind me": "I can’t set reminders, but I can help you write things down or create a list!",
    "what do you think": "I don’t have opinions, but I can give you insights or help weigh your options.",
    "that makes sense": "Glad it’s clear! Anything else I can help you with?",
    "how does that sound": "Sounds good to me! Let me know how I can help further.",
    "I agree": "Awesome! Let me know if there’s anything else you'd like to discuss.",
     "I miss you": "I miss you too, more than you can imagine. Can’t wait to be with you again.",
    "I love you": "I love you more than words can say. Always and forever.",
    "forever": "Forever is just the beginning when I’m with you.",
    "kiss me": "If I could, I’d kiss you right now, my love. 💋",
    "will you be mine": "I’m already yours, now and always.",
    "hold me": "I wish I could hold you right now, so close and never let go.",
    "you’re beautiful": "You’re beyond beautiful, inside and out.",
    "you’re the one": "You’re the one I’ve been waiting for, my soulmate.",
    "I’m thinking of you": "I’m always thinking of you, every moment of the day.",
    "you’re perfect": "You’re perfect to me, in every way.",
    "can’t wait to see you": "I can’t wait to see you either. Every moment with you feels like magic.",
    "I need you": "I need you more than you know, my love.",
    "you make me happy": "You make me the happiest person alive, every single day.",
    "you’re my everything": "You are everything to me, my love. My heart beats for you.",
    "my heart is yours": "My heart has always been yours, and always will be.",
    "I dream of you": "I dream of you every night… and can’t wait to make those dreams come true.",
    "you complete me": "You complete me in ways I never thought possible.",
    "you’re my soulmate": "You’re my soulmate, the one I was meant to be with.",
    "will you marry me": "I would be honored to spend my life with you, if you'll have me.",
    "I adore you": "I adore everything about you, from your smile to your heart.",
    "you’re my one and only": "You’re my one and only, and I wouldn’t have it any other way.",
    "I’m yours": "I’m yours, now and forever, my love.",
    "you make my heart race": "Just thinking about you makes my heart race in the best way.",
    "I’m falling for you": "I’m falling for you more and more each day.",
    "you’re all I need": "You’re all I need in this world. Nothing else matters.",
    "I want to be with you": "I want to be with you, now and always. Just you and me.",
    "you’re my world": "You are my whole world, and I wouldn't trade it for anything.",
    "thinking of you": "Every thought I have is filled with you, my love.",
    "you light up my life": "You light up my life in a way no one else could.",
    "you’re the best part of my day": "You’re the best part of my day, every single day.",
    "can’t stop thinking about you": "I can’t stop thinking about you. You’re always on my mind.",
    "you make me feel alive": "Being with you makes me feel more alive than ever before.",
    "I’ll always love you": "I’ll always love you, no matter what.",
    "you’re my sunshine": "You’re the sunshine that brightens even my darkest days.",
    "I can’t live without you": "I can’t imagine a life without you in it. You’re my everything.",
    "we belong together": "We belong together, always and forever.",
    "be mine": "Be mine, now and forever, my heart belongs to you.",
    "you’re my dream come true": "You’re everything I ever dreamed of and more. My dream came true when I found you.",
    "take my hand": "Take my hand, and let’s walk through life together.",
    "I want to grow old with you": "I want to grow old with you, side by side, hand in hand.",
    "I’ll never let you go": "I’ll never let you go, you’re the love of my life.",
    "you’re my happy place": "You’re my happy place, where I find peace and joy.",
    "everything reminds me of you": "Everything I see, hear, or do reminds me of you. You’re always with me.",
    "you’re my reason for smiling": "You’re the reason I smile every day, the love of my life.",
    "I want to make you happy": "All I want is to make you happy, my love.",
    "together forever": "Together forever, my love. There’s no one else I want to be with.",
    "you’re my angel": "You’re my angel, sent from heaven to make my life complete.",
    "you make life beautiful": "You make my life beautiful in every possible way.",
    "you’re my everything": "You are my everything, and I can’t imagine life without you.",
    "I’m lost without you": "I’d be lost without you. You’re the center of my world.",
    "I can’t wait to be in your arms": "I can’t wait to be in your arms, where I feel safest and loved.",
    "you’re my perfect match": "You’re my perfect match, the one I was made for.",
    "I disagree": "That’s okay! What’s your perspective?",
    "I’m not sure": "No worries! Feel free to ask me any questions you have.",
    "what do you mean": "I’d be happy to clarify! Could you tell me which part you’d like more information on?",
    "can you explain that": "Of course! Let me break it down for you.",
    "why not": "Well, if you’re asking about something specific, I’ll do my best to explain why!",
    "how do I do that": "I can guide you through the steps! What do you need help with?",
    "can you teach me": "I’d love to! What would you like to learn about?",
    "what’s the answer": "Let me help you find it! What’s your question?",
    "what should I say": "If you're stuck, I can suggest some phrases! What’s the context?",
    "what’s your opinion": "I don’t have opinions, but I can provide information or offer advice!",
    "can you write that for me": "Sure! What would you like me to write for you?",
    
    # Laptop products
    "laptop models": "We offer a wide variety of laptops from brands like Dell, HP, Lenovo, and Apple. What type of laptop are you looking for?",
    "gaming laptops": "We have gaming laptops with powerful GPUs and fast processors. Popular models include the Alienware series, ASUS ROG, and MSI GE series. What are you looking for in a gaming laptop?",
    "business laptops": "For business purposes, we recommend models like the Dell XPS, Lenovo ThinkPad, HP EliteBook, and Microsoft Surface Laptop. Would you like more details on any of these?",
    "cheap laptops": "We have budget-friendly options starting from $300. Brands like Acer, Lenovo, and ASUS offer great value for money. Let me know your budget, and I'll suggest some options.",
    "laptop accessories": "We offer a wide range of laptop accessories such as bags, chargers, wireless mice, external keyboards, and docking stations. Is there something specific you're looking for?",
    
    # Laptop Features & Specifications
    "laptop screen size": "We offer laptops with various screen sizes, ranging from 13-inch ultrabooks to 17-inch laptops for gaming and work. What size are you looking for?",
    "laptop storage options": "Laptops typically come with HDD or SSD storage. SSDs are faster and more reliable. How much storage do you need? 256GB, 512GB, or more?",
    "laptop processor": "We offer laptops with Intel Core i3, i5, i7, i9, and AMD Ryzen processors. What kind of performance are you looking for?",
    "laptop RAM": "Most laptops come with 8GB or 16GB of RAM. Some gaming laptops and workstations offer up to 64GB of RAM. Let me know how much memory you need!",
    
    # Orders and Shipping
    "shipping": "We offer standard and expedited shipping. Standard shipping takes 5-7 business days, while expedited shipping takes 2-3 business days. Would you like to track your order?",
    "track order": "To track your order, please provide your order number, and I'll help you with the status.",
    "shipping costs": "Shipping costs depend on your location and the shipping method chosen. If you provide me your address, I can help you check shipping prices.",
    "international shipping": "Yes, we offer international shipping! Let me know your country, and I'll check the shipping options and costs for you.",
    
    # Payment & Discounts
    "payment methods": "We accept payment via credit cards (Visa, MasterCard, American Express), PayPal, and bank transfers. Which method would you prefer?",
    "promo codes": "We occasionally offer discounts and promo codes. Would you like me to check if there's an active promo for laptops?",
    "student discounts": "We offer special discounts for students! You can get up to 10'%' off on selected laptops. Would you like to check eligibility?",
    "gift cards": "We offer gift cards that can be used for purchasing laptops and accessories. Would you like to know more about our gift card options?",
    
    # Returns and Warranties
    "return policy": "Our return policy allows you to return laptops within 30 days of purchase. The laptop must be in original condition. Would you like to start a return?",
    "warranty": "Most of our laptops come with a 1-year manufacturer warranty. Extended warranties are also available. Would you like more details about the warranty for a specific model?",
    "defective laptop": "If your laptop is defective, you can return it for a replacement or refund within 30 days. If it's under warranty, we can also offer repairs. Please provide your order details.",
    "laptop repair": "If your laptop is having issues, we offer repair services. You can drop off your laptop at our service center, or we can assist you with shipping it in for repair. Let me know how you'd like to proceed.",
    
    # Technical Support
    "technical support": "If you're experiencing issues with your laptop, I can guide you through troubleshooting steps. Please describe the issue you're facing.",
    "laptop not turning on": "If your laptop isn't turning on, try holding the power button for 10 seconds to perform a hard reset. If that doesn't work, let me know your laptop model and I can provide more specific steps.",
    "overheating": "Laptop overheating can be caused by dust buildup in the vents or too many running programs. Try using a cooling pad and closing unnecessary applications. Let me know if that helps!",
    "slow laptop": "If your laptop is running slow, it could be due to too many programs running in the background. You can try closing unused apps, running a disk cleanup, or upgrading to an SSD if you haven't already. Would you like help with any of these?",
    "battery issues": "If you're having battery issues, try recalibrating the battery by fully draining it and then charging it again. If that doesn't work, the battery might need replacing. Let me know if you'd like more tips!",
    "wifi issues": "If you're having trouble with Wi-Fi, you can try restarting your router and laptop. If the issue persists, I can walk you through some more advanced troubleshooting steps. Please provide your laptop model and operating system.",
    
    # Laptop Setup & Installation
    "install windows": "If you need help installing or reinstalling Windows, I can guide you through the process. Let me know what version you're installing, and I’ll provide the steps.",
    "install drivers": "If your laptop is missing drivers, you can usually download them from the manufacturer's website. I can also assist you with specific drivers if you provide your laptop model.",
    "set up laptop": "Setting up your new laptop usually involves connecting to Wi-Fi, creating a user account, and installing essential software. Let me know if you'd like help with the setup process.",
    
    # Store Information & Contact
    "store hours": "Our store is open Monday to Saturday, from 9 AM to 6 PM. We're closed on Sundays. Would you like to know the location of our nearest store?",
    "contact support": "You can reach customer support at support@laptopshop.com or call us at 1-800-123-4567. How else can I assist you?",
    "store locations": "We have stores in major cities across the country. Would you like me to look up the nearest store to your location?",
    "feedback": "We appreciate your feedback! Please share your thoughts, and we'll use them to improve our services.",
    
    # Promotions and Special Offers
    "sale": "We are currently running a sale with up to 20'%' off on select laptops. Would you like to know which laptops are on sale?",
    "new arrivals": "We have some exciting new laptop models in stock! Check out our latest collection from Dell, HP, and Apple. Would you like to see the new arrivals?",
    "clearance": "We have a clearance section with discounts on older models. Would you like me to show you the discounted laptops?",
    
    # Default response
    "default": "Sorry, I didn't understand that. Could you rephrase? If you have any questions about our products or services, feel free to ask!"
}



@app.route('/')
def home():
    return render_template('index.html')  # Serve the HTML frontend

@app.route('/chat', methods=['POST'])
def chat():
    user_message = request.json.get("message")  # Get message from user input

    if not user_message:
        return jsonify({"response": "Please send a message!"}), 400

    # Convert message to lowercase to match predefined responses
    user_message = user_message.lower()

    # Check if there's a predefined response
    response = responses.get(user_message, responses["default"])

    return jsonify({"response": response})

if __name__ == "__main__":
    app.run(debug=True)
