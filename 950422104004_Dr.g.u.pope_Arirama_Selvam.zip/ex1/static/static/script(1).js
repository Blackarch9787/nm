// Function to send the message to Flask backend
function sendMessage() {
    const userInput = document.getElementById('userInput').value;
    if (userInput.trim() === "") return;

    // Add the user's message to the chat box
    addMessage(userInput, "user");

    // Clear the input field
    document.getElementById('userInput').value = "";

    // Send the message to Flask server
    fetch('/chat', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ message: userInput })
    })
    .then(response => response.json())
    .then(data => {
        // Add the bot's response to the chat box
        addMessage(data.response, "bot");
    })
    .catch(error => {
        console.error("Error:", error);
    });
}

// Function to add a message to the chat box
function addMessage(message, sender) {
    const chatBox = document.getElementById('chatBox');

    const messageDiv = document.createElement('div');
    messageDiv.classList.add(sender === 'user' ? 'user-message' : 'bot-message');
    messageDiv.textContent = message;
    
    chatBox.appendChild(messageDiv);

    // Scroll to the bottom of the chat box
    chatBox.scrollTop = chatBox.scrollHeight;
}
